import LayoutContainer from "./layout.template";

export default LayoutContainer;