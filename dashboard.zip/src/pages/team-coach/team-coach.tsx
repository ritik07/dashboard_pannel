import React, { useState } from "react";
import CSS from "./team-coach.module.scss";
import PageHeader from "../../components/page-header/page-header";
import { TeamOutlined, HistoryOutlined } from "@ant-design/icons";
import { Col, Divider, Pagination, Row, Space, Tabs, Typography } from "antd";
import CardId from "./component/card-id/card-id";
import Sider from "./component/sider/sider";
import FeatureCard from "../claims/feature-card/feature-card";
import type { TabsProps } from "antd";
import All from "./component/tabs/all/all";

interface ClaimData {
  name: string;
  status: string;
}

const TeamCoach = () => {
  const DUMMY_DATA = [{ name: "Rajesh kumar" }, { name: "Swathi Reddy" }];
  const [filterBy, setFilterBy] = useState<number>(1);
  const [currentPage, setCurrentPage] = useState<number>(1);
  const pageSize = 5; // Number of items per page

  const data: ClaimData[] = [
    { name: "coach 1", status: "Approved" },
    { name: "coach 2", status: "Approved" },
    { name: "coach 3", status: "Pending" },
    { name: "coach 3", status: "Pending" },
    { name: "coach 3", status: "Pending" },
    { name: "coach 3", status: "Pending" },
    { name: "coach 3", status: "Pending" },
    { name: "coach 3", status: "Pending" },
    { name: "coach 3", status: "Pending" },
    { name: "coach 3", status: "Pending" },
    // Add more data as needed
  ];

  const filteredData = data.filter((item) => {
    if (filterBy === 1) return true; // All
    return item.status === (filterBy === 2 ? "Approved" : "Pending");
  });

  const totalItems = filteredData.length;
  const startIndex = (currentPage - 1) * pageSize;
  const endIndex = startIndex + pageSize;
  const displayedData = filteredData.slice(startIndex, endIndex);

  const items: TabsProps["items"] = [
    {
      key: "1",
      label: "All",
      children: <All data={displayedData} filterBy={filterBy} />,
    },
    {
      key: "2",
      label: "Approved",
      children: <All data={displayedData} filterBy={filterBy} />,
    },
    {
      key: "3",
      label: "Pending",
      children: <All data={displayedData} filterBy={filterBy} />,
    },
  ];

  const onChangeFilter = (key: string) => {
    setFilterBy(Number(key));
    setCurrentPage(1); // Reset page when changing filter
  };

  const onChangePage = (page: number) => {
    setCurrentPage(page);
  };

  const onChange = (key: any) => {
    setFilterBy(key);
  };
  return (
    <div className={CSS.container}>
      <PageHeader Icon={TeamOutlined} Title="Team Coach" Description="lorem" />

      <Divider className="cs-tm-20 cs-bm-30" />

      <div className="cs-tm-40">
        <Row gutter={[20, 20]}>
          <Col xs={24} xl={18}>
            <Space direction="horizontal">
              <HistoryOutlined className={CSS.verified} />

              <Typography.Title level={5} className={CSS.verified}>
                Active Coach
              </Typography.Title>
            </Space>

            <div>
              <CardId data={DUMMY_DATA} />
            </div>

            <div className="cs-tm-40">
              <div>
                <Space direction="horizontal">
                  <HistoryOutlined className={CSS.verified} />

                  <Typography.Title level={5} className={CSS.verified}>
                    Coach History
                  </Typography.Title>
                </Space>
                <Row gutter={[20, 20]} className="cs-tm-10">
                  <Col xl={24} xs={24}>
                    <Tabs
                      defaultActiveKey="1"
                      items={items}
                      onChange={onChangeFilter}
                    />
                    <Divider className="cs-tm-20 cs-bm-30" />
                    <div className="cs-dis-flex cs-hrz-center">
                      <Pagination
                        defaultCurrent={1}
                        current={currentPage}
                        total={totalItems}
                        pageSize={pageSize}
                        onChange={onChangePage}
                      />
                    </div>
                  </Col>
                </Row>
              </div>
            </div>
          </Col>
          <Col xs={24} xl={6}>
            <Sider />
          </Col>
        </Row>
      </div>
    </div>
  );
};

export default TeamCoach;
