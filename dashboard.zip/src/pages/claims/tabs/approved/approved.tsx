import React from "react";

const Approved = () => {
  return <div>Approved</div>;
};

export default Approved;
